# Media

- `images/` contains supplied project images/logo.
- `videos/` contains supplied prototype demo clips.
- Before making the repository public, verify that you own or have permission to publish all people, locations, and media shown.
- Add captions with actual dates and test context; do not imply a demo screenshot proves measured radio performance.
