# ZONEZAP — DEAD ZONE KILLER (DZK-1)
### Balloon-Based Emergency Communication & Disaster Management System using LoRa

<p align="center">
  <img src="media/images/zonezap_logo.png" alt="ZoneZap logo" width="300">
</p>

<p align="center">
  <b>Offline-first emergency messaging • Balloon relay concept • LoRa telemetry • Ground-station dashboard</b>
</p>

> **Project status:** Prototype / research project. This repository combines the supplied project photographs and demo videos with an organized software, firmware, hardware, testing, and documentation structure. Firmware and dashboard examples are reference implementations and must be validated against the exact hardware before field use.

## Overview
ZONEZAP (DZK-1) is a prototype concept for restoring short-range emergency messaging when conventional cellular or internet infrastructure is unavailable or damaged. A local user node accepts a message, a LoRa link forwards compact packets to a relay node, and a ground station displays received telemetry and mission status. A balloon may raise the relay antenna to improve line-of-sight coverage, subject to payload, power, radio, weather, aviation, and local regulatory constraints.

## System architecture
```text
[Phone / local user interface]
           |
           v
[User Node: ESP32 + LoRa]
           )))) LoRa RF link ((((
[Balloon Relay: ESP32 + LoRa + GPS]
           )))) LoRa RF link ((((
[Ground Station: ESP32/USB serial]
           |
           v
[Browser dashboard: map, link, battery, temperature, alerts]
```

Depending on the actual hardware setup, the system can be tested first with two ground-level nodes before attempting any tethered or elevated relay experiment.

## Repository map
- `firmware/user_node/` — user-side message transmitter reference firmware.
- `firmware/balloon_relay/` — relay/telemetry firmware reference.
- `firmware/ground_station/` — serial-to-dashboard bridge reference.
- `dashboard/` — responsive demo dashboard with simulated data and serial input option.
- `hardware/` — pin-map template, bill of materials, and wiring notes.
- `docs/` — architecture, packet format, safety, testing, and contribution guidance.
- `tests/` — packet-format and dashboard smoke-test notes.
- `media/images/`, `media/videos/` — supplied project visuals and demo videos.

## Quick start: dashboard
Open `dashboard/index.html` in a modern browser. The page runs in **DEMO mode** by default and shows simulated telemetry. This does not mean live LoRa telemetry is connected. Use the Serial USB section only after connecting a compatible serial bridge and verifying the expected JSON-lines packet format.

## Quick start: firmware
1. Install Arduino IDE and the ESP32 board package.
2. Install the `LoRa` library by Sandeep Mistry and `TinyGPSPlus` if using GPS.
3. Confirm the exact board, LoRa module, radio frequency, antenna connector, pinout, and regional radio rules.
4. Review `hardware/pinmap-template.md` and update pins for your actual wiring.
5. Compile and test one node at a time at low power on a bench.
6. Verify packet CRC, packet-loss behavior, timeout behavior, and emergency-alert logic before any outdoor test.

## Example serial packet
The dashboard accepts one JSON object per line, for example:
```json
{"type":"telemetry","node":"relay-01","rssi":-68,"battery":94,"temperature":28.4,"lat":17.7,"lon":83.2,"alert":"NORMAL","seq":42}
```
Values above are illustrative only, not measured performance data.

## Evidence and media
Prototype images are in `media/images/`; supplied demo videos are in `media/videos/`. Use them as project evidence and update captions with the real test date, setup, and results before publication.

## Research and performance claims
Do not report range, latency, packet delivery ratio, altitude, battery runtime, or emergency-service readiness as measured unless you have logged repeatable experimental data. See `docs/experimental-protocol.md`.

## Safety and limitations
- This is not a certified emergency communication system and must not replace public-safety networks.
- Use only radio frequencies, output power, antennas, and duty cycles permitted in your jurisdiction.
- Do not launch a balloon or operate tethered aerial equipment without checking applicable aviation, landowner, weather, electrical, and local permissions.
- Keep a ground-level test plan and a fail-safe recovery plan.
- Do not transmit personal or sensitive information in unencrypted demonstration packets.

## License
Code and documentation are provided under the MIT License unless a media file has separate rights or permissions. Uploaded photographs and videos remain the property of their respective rights holders; obtain permission before redistributing them publicly.
